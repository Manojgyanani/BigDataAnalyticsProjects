import java.beans.FeatureDescriptor;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

import javax.print.attribute.standard.RequestingUserName;
import javax.xml.crypto.Data;

public class Main {

	public static void main(String[] args) throws IOException 
	{
//		String argu = args[0];
//
//		String toks[] = argu.split("~");
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter Product");
		String Feature_1 = scanner.nextLine();
		System.out.println("Enter Issue");
		String Feature_2 = scanner.nextLine();
		System.out.println("Enter COmpany");
		String Feature_3 = scanner.nextLine();
//		System.out.println(toks[0]);
//		System.out.println(toks[1]);
//		System.out.println(toks[2]);
		String line;
		HashSet<String> targets = new HashSet<>();
		FileReader fileReader = 
				new FileReader("C:\\Users\\manoj\\Desktop\\000000_0");
		
		ArrayList<String> tarSpecific = new ArrayList<>();

		// Always wrap FileReader in BufferedReader.
		BufferedReader bufferedReader = new BufferedReader(fileReader);

		Double Total_tuples = 0.0;
		
		while((line = bufferedReader.readLine()) != null) {
			//System.out.println(line);
			
			 String[] tokens = line.split("");
		        
			 
			 targets.add(tokens[3]);
			
			 Total_tuples++;

		}
		//System.out.println(Total_tuples);
		
		// P[Target|A,B,C] = P[Target] * P[A|Target] * P[B|TARGET] * P[C\TARGET];
		Double finalProbablity=0.0;
		String finalTarget="";
		
		for(String tar : targets)
		{
			Double localProbability=1.0;
			Double P_Target=0.0;
			Double P_A_Target=0.0;
			Double P_B_Target=0.0;
			Double P_C_Target=0.0;
			Double A_Count = 0.0;
			Double B_Count = 0.0;
			Double C_Count = 0.0;
			//System.out.println(tar);
			Double Target_Count=0.0;
			FileReader fileReader2 =	new FileReader("C:\\Users\\manoj\\Desktop\\000000_0");
			bufferedReader = new BufferedReader(fileReader2);
			while((line = bufferedReader.readLine()) != null) 
			{
				String[] tokens = line.split("");
				
				if(tokens[3].equalsIgnoreCase(tar))
				{
					Target_Count++;
					
					if(tokens[0].equalsIgnoreCase(Feature_1))
					{
						A_Count++;
					}
					if(tokens[1].equalsIgnoreCase(Feature_2))
					{
						B_Count++;
					}
					if(tokens[2].equalsIgnoreCase(Feature_3))
					{
						C_Count++;
					}
				}
			}
			
			P_Target=Target_Count/Total_tuples;
			P_A_Target=A_Count/Target_Count;
			P_B_Target=B_Count/Target_Count;
			P_C_Target=C_Count/Target_Count;
			localProbability=P_Target*P_A_Target*P_B_Target*P_C_Target;
//			System.out.println("localProb :"+localProbability);
//			System.out.println("Local Target :"+tar);
			if(localProbability>finalProbablity)
			{
				finalProbablity=localProbability;
				finalTarget=tar;
			}
		}
		System.out.println(finalProbablity+" "+finalTarget);
		
		
		
	}
}


